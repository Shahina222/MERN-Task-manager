const express = require("express");
const Task = require("../models/Task");

module.exports = (io) => {
  const router = express.Router();

  router.get("/:email", async (req, res) => {
    const tasks = await Task.find({ $or: [{ owner: req.params.email }, { sharedWith: req.params.email }] });
    res.json(tasks);
  });

  router.post("/", async (req, res) => {
    const task = new Task(req.body);
    await task.save();
    io.emit("refreshTasks");
    res.json(task);
  });

  router.put("/:id", async (req, res) => {
    const task = await Task.findByIdAndUpdate(req.params.id, req.body, { new: true });
    io.emit("refreshTasks");
    res.json(task);
  });

  router.delete("/:id", async (req, res) => {
    await Task.findByIdAndDelete(req.params.id);
    io.emit("refreshTasks");
    res.json({ message: "Task deleted" });
  });

  return router;
};