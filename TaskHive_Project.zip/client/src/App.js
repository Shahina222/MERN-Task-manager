import React, { useEffect, useState } from "react";
import io from "socket.io-client";
import axios from "axios";

const socket = io("http://localhost:5000");

function App() {
  const [tasks, setTasks] = useState([]);

  const fetchTasks = async () => {
    const res = await axios.get("http://localhost:5000/api/tasks/youremail@example.com");
    setTasks(res.data);
  };

  useEffect(() => {
    fetchTasks();
    socket.on("refreshTasks", fetchTasks);
    return () => socket.off("refreshTasks");
  }, []);

  return (
    <div className="p-4">
      <h1 className="text-xl font-bold mb-4">TaskHive Dashboard</h1>
      {tasks.map((task) => (
        <div key={task._id} className="border p-2 mb-2 rounded">
          <h2>{task.title}</h2>
          <p>{task.description}</p>
        </div>
      ))}
    </div>
  );
}

export default App;